
package android.ble.wcm.microchip.com.microchip.api.model.Status;

public class Mchp {

    public Device device;

    public Mchp(){
        device = new Device();
    }

}
