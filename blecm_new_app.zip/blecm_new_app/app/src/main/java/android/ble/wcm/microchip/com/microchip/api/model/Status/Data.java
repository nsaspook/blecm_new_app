package android.ble.wcm.microchip.com.microchip.api.model.Status;

public class Data {

    public Boolean button1 = false;
    public Boolean button2 = false;
    public Boolean button3 = false;
    public Boolean button4 = false;
    public Boolean led1 = false;
    public Boolean led2 = false;
    public Boolean led3 = false;
    public Boolean led4 = false;
    public Boolean relay1 = false;
    public Boolean relay2 = false;
    public Boolean relay3 = false;
    public Boolean relay4 = false;
    public Integer potentiometer = 0;
    public Boolean adc_data = false;
    public Boolean pic_slave = false;

}
