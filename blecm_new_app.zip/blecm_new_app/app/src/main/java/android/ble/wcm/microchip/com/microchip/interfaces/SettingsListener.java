package android.ble.wcm.microchip.com.microchip.interfaces;

/**
 * Created by: WillowTree
 * Date: 1/8/15
 * Time: 1:41 PM
 */
public interface SettingsListener {
    void onSettingsOpened();
    void onSettingsClosed();
}
